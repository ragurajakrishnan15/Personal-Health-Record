"""AI service — Gemini-powered document extraction and health chat.

TODO (Claude Code):
- Implement extract_from_document() with Gemini vision API
- Implement chat_with_health_assistant() with RAG context
- Add confidence scoring
- Add medical entity normalization
"""
import os
from dotenv import load_dotenv

load_dotenv()

GEMINI_API_KEY = os.getenv("GEMINI_API_KEY")


async def extract_from_document(file_path: str, file_type: str) -> dict:
    """Extract structured medical data from an uploaded document.

    Should use Gemini to:
    1. Read/OCR the document
    2. Classify it (prescription, lab report, discharge summary, etc.)
    3. Extract structured fields based on category
    4. Return JSON with extracted data + confidence scores

    Returns:
        {
            "category": "prescription" | "lab_report" | "discharge_summary" | ...,
            "document_date": "YYYY-MM-DD",
            "doctor": "...",
            "hospital": "...",
            "medications": [...],
            "lab_results": [...],
            "diagnoses": [...],
            "follow_up_date": "...",
            "raw_text": "...",
            "confidence": 0.0-1.0
        }
    """
    # TODO: Implement with google.generativeai
    return {
        "category": "other",
        "document_date": None,
        "doctor": None,
        "hospital": None,
        "medications": [],
        "lab_results": [],
        "diagnoses": [],
        "follow_up_date": None,
        "raw_text": "",
        "confidence": 0.0,
    }


async def chat_with_health_assistant(
    patient_id: int,
    message: str,
    patient_context: dict,
    chat_history: list[dict],
) -> str:
    """Answer health queries using patient records as context (RAG).

    Should:
    1. Build context from patient's records (medications, labs, consultations)
    2. Send to Gemini with system prompt + context + chat history
    3. Ground responses in actual patient data
    4. Add source references
    5. Avoid fabricating medical info

    Returns:
        AI response string
    """
    # TODO: Implement with google.generativeai
    return "AI health assistant not yet connected. Configure your Gemini API key and implement this function."
