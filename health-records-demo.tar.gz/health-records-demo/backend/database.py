"""Database models — SQLAlchemy + SQLite."""
import datetime
from sqlalchemy import (
    create_engine, Column, Integer, String, Text, Float,
    DateTime, Boolean, ForeignKey, JSON,
)
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker, relationship

DATABASE_URL = "sqlite:///./health_records.db"
engine = create_engine(DATABASE_URL, connect_args={"check_same_thread": False})
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)
Base = declarative_base()


# ── Patients ──────────────────────────────────────────────
class Patient(Base):
    __tablename__ = "patients"
    id = Column(Integer, primary_key=True, index=True)
    name = Column(String, nullable=False)
    age = Column(Integer)
    gender = Column(String)
    blood_group = Column(String)
    phone = Column(String)
    email = Column(String)
    created_at = Column(DateTime, default=datetime.datetime.utcnow)

    documents = relationship("MedicalDocument", back_populates="patient")
    medications = relationship("Medication", back_populates="patient")
    lab_results = relationship("LabResult", back_populates="patient")
    consultations = relationship("Consultation", back_populates="patient")
    allergies = relationship("Allergy", back_populates="patient")
    timeline_events = relationship("TimelineEvent", back_populates="patient")


# ── Documents ─────────────────────────────────────────────
class MedicalDocument(Base):
    __tablename__ = "medical_documents"
    id = Column(Integer, primary_key=True, index=True)
    patient_id = Column(Integer, ForeignKey("patients.id"), nullable=False)
    filename = Column(String, nullable=False)
    file_path = Column(String, nullable=False)
    category = Column(String, default="other")
    document_date = Column(String)
    upload_date = Column(DateTime, default=datetime.datetime.utcnow)
    hospital = Column(String)
    doctor = Column(String)
    extracted_data = Column(JSON)
    validation_status = Column(String, default="pending_review")
    notes = Column(Text)

    patient = relationship("Patient", back_populates="documents")


# ── Medications ───────────────────────────────────────────
class Medication(Base):
    __tablename__ = "medications"
    id = Column(Integer, primary_key=True, index=True)
    patient_id = Column(Integer, ForeignKey("patients.id"), nullable=False)
    document_id = Column(Integer, ForeignKey("medical_documents.id"), nullable=True)
    name = Column(String, nullable=False)
    generic_name = Column(String)
    strength = Column(String)
    dosage = Column(String)
    frequency = Column(String)
    route = Column(String)
    timing = Column(String)
    instructions = Column(String)
    start_date = Column(String)
    end_date = Column(String)
    prescribing_doctor = Column(String)
    status = Column(String, default="active")
    confidence = Column(Float)

    patient = relationship("Patient", back_populates="medications")


# ── Lab Results ───────────────────────────────────────────
class LabResult(Base):
    __tablename__ = "lab_results"
    id = Column(Integer, primary_key=True, index=True)
    patient_id = Column(Integer, ForeignKey("patients.id"), nullable=False)
    document_id = Column(Integer, ForeignKey("medical_documents.id"), nullable=True)
    lab_name = Column(String)
    report_date = Column(String)
    test_name = Column(String, nullable=False)
    test_value = Column(String)
    unit = Column(String)
    reference_range = Column(String)
    is_abnormal = Column(Boolean, default=False)
    specimen_type = Column(String)
    comments = Column(Text)
    confidence = Column(Float)

    patient = relationship("Patient", back_populates="lab_results")


# ── Consultations ─────────────────────────────────────────
class Consultation(Base):
    __tablename__ = "consultations"
    id = Column(Integer, primary_key=True, index=True)
    patient_id = Column(Integer, ForeignKey("patients.id"), nullable=False)
    document_id = Column(Integer, ForeignKey("medical_documents.id"), nullable=True)
    doctor_name = Column(String)
    hospital = Column(String)
    consultation_date = Column(String)
    diagnosis = Column(Text)
    symptoms = Column(Text)
    follow_up_date = Column(String)
    notes = Column(Text)
    confidence = Column(Float)

    patient = relationship("Patient", back_populates="consultations")


# ── Allergies ─────────────────────────────────────────────
class Allergy(Base):
    __tablename__ = "allergies"
    id = Column(Integer, primary_key=True, index=True)
    patient_id = Column(Integer, ForeignKey("patients.id"), nullable=False)
    allergen = Column(String, nullable=False)
    reaction = Column(String)
    severity = Column(String)

    patient = relationship("Patient", back_populates="allergies")


# ── Timeline ──────────────────────────────────────────────
class TimelineEvent(Base):
    __tablename__ = "timeline_events"
    id = Column(Integer, primary_key=True, index=True)
    patient_id = Column(Integer, ForeignKey("patients.id"), nullable=False)
    document_id = Column(Integer, ForeignKey("medical_documents.id"), nullable=True)
    event_date = Column(String, nullable=False)
    event_type = Column(String, nullable=False)
    title = Column(String, nullable=False)
    description = Column(Text)
    created_at = Column(DateTime, default=datetime.datetime.utcnow)

    patient = relationship("Patient", back_populates="timeline_events")


# ── Chat ──────────────────────────────────────────────────
class ChatMessage(Base):
    __tablename__ = "chat_messages"
    id = Column(Integer, primary_key=True, index=True)
    patient_id = Column(Integer, ForeignKey("patients.id"), nullable=False)
    role = Column(String, nullable=False)
    content = Column(Text, nullable=False)
    created_at = Column(DateTime, default=datetime.datetime.utcnow)


# ── Helpers ───────────────────────────────────────────────
def init_db():
    Base.metadata.create_all(bind=engine)


def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()
