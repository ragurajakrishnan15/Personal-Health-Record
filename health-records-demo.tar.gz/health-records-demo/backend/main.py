"""FastAPI backend for Personal Health Records Platform."""
import os
import shutil
from datetime import datetime
from fastapi import FastAPI, UploadFile, File, Depends, HTTPException, Query
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from sqlalchemy.orm import Session
from pydantic import BaseModel

from database import init_db, get_db, Patient, MedicalDocument, Medication, \
    LabResult, Consultation, Allergy, TimelineEvent, ChatMessage
from ai_service import extract_from_document, chat_with_health_assistant

app = FastAPI(title="Health Records Platform API", version="0.1.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

UPLOAD_DIR = os.getenv("UPLOAD_DIR", "../uploads")
os.makedirs(UPLOAD_DIR, exist_ok=True)


@app.on_event("startup")
def startup():
    init_db()
    # TODO: Seed demo patient if DB is empty


# ══════════════════════════════════════════════════════════
#  Pydantic schemas
# ══════════════════════════════════════════════════════════

class PatientCreate(BaseModel):
    name: str
    age: int | None = None
    gender: str | None = None
    blood_group: str | None = None
    phone: str | None = None
    email: str | None = None

class PatientOut(BaseModel):
    id: int
    name: str
    age: int | None
    gender: str | None
    blood_group: str | None
    phone: str | None
    email: str | None
    class Config:
        from_attributes = True

class MedicationOut(BaseModel):
    id: int
    name: str
    generic_name: str | None
    strength: str | None
    dosage: str | None
    frequency: str | None
    timing: str | None
    instructions: str | None
    start_date: str | None
    end_date: str | None
    prescribing_doctor: str | None
    status: str
    class Config:
        from_attributes = True

class LabResultOut(BaseModel):
    id: int
    test_name: str
    test_value: str | None
    unit: str | None
    reference_range: str | None
    is_abnormal: bool
    report_date: str | None
    lab_name: str | None
    class Config:
        from_attributes = True

class DocumentOut(BaseModel):
    id: int
    filename: str
    category: str
    document_date: str | None
    upload_date: datetime | None
    hospital: str | None
    doctor: str | None
    validation_status: str
    extracted_data: dict | None
    class Config:
        from_attributes = True

class TimelineEventOut(BaseModel):
    id: int
    event_date: str
    event_type: str
    title: str
    description: str | None
    class Config:
        from_attributes = True

class ChatRequest(BaseModel):
    patient_id: int
    message: str

class ChatResponse(BaseModel):
    reply: str

class ValidationUpdate(BaseModel):
    validation_status: str  # verified, corrected, rejected
    corrected_data: dict | None = None


# ══════════════════════════════════════════════════════════
#  PATIENTS
# ══════════════════════════════════════════════════════════

@app.post("/api/patients", response_model=PatientOut)
def create_patient(patient: PatientCreate, db: Session = Depends(get_db)):
    db_patient = Patient(**patient.model_dump())
    db.add(db_patient)
    db.commit()
    db.refresh(db_patient)
    return db_patient


@app.get("/api/patients", response_model=list[PatientOut])
def list_patients(db: Session = Depends(get_db)):
    return db.query(Patient).all()


@app.get("/api/patients/{patient_id}", response_model=PatientOut)
def get_patient(patient_id: int, db: Session = Depends(get_db)):
    patient = db.query(Patient).filter(Patient.id == patient_id).first()
    if not patient:
        raise HTTPException(404, "Patient not found")
    return patient


# ══════════════════════════════════════════════════════════
#  DOCUMENT UPLOAD & AI EXTRACTION
# ══════════════════════════════════════════════════════════

@app.post("/api/patients/{patient_id}/documents", response_model=DocumentOut)
async def upload_document(
    patient_id: int,
    file: UploadFile = File(...),
    db: Session = Depends(get_db),
):
    """Upload a medical document → AI extracts structured data → save for validation."""
    patient = db.query(Patient).filter(Patient.id == patient_id).first()
    if not patient:
        raise HTTPException(404, "Patient not found")

    # Save file
    file_path = os.path.join(UPLOAD_DIR, f"{patient_id}_{file.filename}")
    with open(file_path, "wb") as f:
        shutil.copyfileobj(file.file, f)

    # AI extraction
    extracted = await extract_from_document(file_path, file.content_type)

    # Save document record
    doc = MedicalDocument(
        patient_id=patient_id,
        filename=file.filename,
        file_path=file_path,
        category=extracted.get("category", "other"),
        document_date=extracted.get("document_date"),
        hospital=extracted.get("hospital"),
        doctor=extracted.get("doctor"),
        extracted_data=extracted,
        validation_status="pending_review",
    )
    db.add(doc)
    db.commit()
    db.refresh(doc)

    # TODO: Create Medication / LabResult / Consultation records from extracted data
    # TODO: Create TimelineEvent entries

    return doc


@app.get("/api/patients/{patient_id}/documents", response_model=list[DocumentOut])
def list_documents(patient_id: int, db: Session = Depends(get_db)):
    return db.query(MedicalDocument).filter(
        MedicalDocument.patient_id == patient_id
    ).order_by(MedicalDocument.upload_date.desc()).all()


@app.put("/api/documents/{doc_id}/validate")
def validate_document(doc_id: int, body: ValidationUpdate, db: Session = Depends(get_db)):
    """User validates/corrects AI-extracted data."""
    doc = db.query(MedicalDocument).filter(MedicalDocument.id == doc_id).first()
    if not doc:
        raise HTTPException(404, "Document not found")
    doc.validation_status = body.validation_status
    if body.corrected_data:
        doc.extracted_data = body.corrected_data
    db.commit()
    return {"status": "updated"}


# ══════════════════════════════════════════════════════════
#  MEDICATIONS
# ══════════════════════════════════════════════════════════

@app.get("/api/patients/{patient_id}/medications", response_model=list[MedicationOut])
def list_medications(
    patient_id: int,
    status: str | None = None,
    db: Session = Depends(get_db),
):
    q = db.query(Medication).filter(Medication.patient_id == patient_id)
    if status:
        q = q.filter(Medication.status == status)
    return q.all()


@app.put("/api/medications/{med_id}/status")
def update_medication_status(med_id: int, status: str = Query(...), db: Session = Depends(get_db)):
    med = db.query(Medication).filter(Medication.id == med_id).first()
    if not med:
        raise HTTPException(404, "Medication not found")
    med.status = status
    db.commit()
    return {"status": "updated"}


# ══════════════════════════════════════════════════════════
#  LAB RESULTS
# ══════════════════════════════════════════════════════════

@app.get("/api/patients/{patient_id}/lab-results", response_model=list[LabResultOut])
def list_lab_results(
    patient_id: int,
    test_name: str | None = None,
    db: Session = Depends(get_db),
):
    q = db.query(LabResult).filter(LabResult.patient_id == patient_id)
    if test_name:
        q = q.filter(LabResult.test_name.ilike(f"%{test_name}%"))
    return q.order_by(LabResult.report_date.desc()).all()


# ══════════════════════════════════════════════════════════
#  TIMELINE
# ══════════════════════════════════════════════════════════

@app.get("/api/patients/{patient_id}/timeline", response_model=list[TimelineEventOut])
def get_timeline(patient_id: int, db: Session = Depends(get_db)):
    return db.query(TimelineEvent).filter(
        TimelineEvent.patient_id == patient_id
    ).order_by(TimelineEvent.event_date.desc()).all()


# ══════════════════════════════════════════════════════════
#  AI CHAT
# ══════════════════════════════════════════════════════════

@app.post("/api/chat", response_model=ChatResponse)
async def chat(req: ChatRequest, db: Session = Depends(get_db)):
    """Conversational health assistant with RAG over patient records."""
    patient = db.query(Patient).filter(Patient.id == req.patient_id).first()
    if not patient:
        raise HTTPException(404, "Patient not found")

    # Build patient context
    # TODO: Gather medications, lab results, consultations, allergies
    patient_context = {"name": patient.name}

    # Get recent chat history
    history = db.query(ChatMessage).filter(
        ChatMessage.patient_id == req.patient_id
    ).order_by(ChatMessage.created_at.desc()).limit(20).all()
    chat_history = [{"role": m.role, "content": m.content} for m in reversed(history)]

    # Save user message
    db.add(ChatMessage(patient_id=req.patient_id, role="user", content=req.message))

    # Get AI response
    reply = await chat_with_health_assistant(
        patient_id=req.patient_id,
        message=req.message,
        patient_context=patient_context,
        chat_history=chat_history,
    )

    # Save assistant message
    db.add(ChatMessage(patient_id=req.patient_id, role="assistant", content=reply))
    db.commit()

    return ChatResponse(reply=reply)


@app.get("/api/patients/{patient_id}/chat-history")
def get_chat_history(patient_id: int, db: Session = Depends(get_db)):
    messages = db.query(ChatMessage).filter(
        ChatMessage.patient_id == patient_id
    ).order_by(ChatMessage.created_at.asc()).all()
    return [{"role": m.role, "content": m.content, "created_at": m.created_at} for m in messages]


# ══════════════════════════════════════════════════════════
#  HEALTH ANALYTICS (summary endpoint)
# ══════════════════════════════════════════════════════════

@app.get("/api/patients/{patient_id}/health-summary")
def get_health_summary(patient_id: int, db: Session = Depends(get_db)):
    """Dashboard summary: active meds count, recent labs, upcoming appointments, etc."""
    patient = db.query(Patient).filter(Patient.id == patient_id).first()
    if not patient:
        raise HTTPException(404, "Patient not found")

    active_meds = db.query(Medication).filter(
        Medication.patient_id == patient_id,
        Medication.status == "active",
    ).count()

    total_docs = db.query(MedicalDocument).filter(
        MedicalDocument.patient_id == patient_id
    ).count()

    pending_reviews = db.query(MedicalDocument).filter(
        MedicalDocument.patient_id == patient_id,
        MedicalDocument.validation_status == "pending_review",
    ).count()

    recent_labs = db.query(LabResult).filter(
        LabResult.patient_id == patient_id
    ).order_by(LabResult.report_date.desc()).limit(5).all()

    return {
        "patient": {"id": patient.id, "name": patient.name},
        "active_medications": active_meds,
        "total_documents": total_docs,
        "pending_reviews": pending_reviews,
        "recent_labs": [
            {"test": r.test_name, "value": r.test_value, "unit": r.unit,
             "date": r.report_date, "abnormal": r.is_abnormal}
            for r in recent_labs
        ],
    }


if __name__ == "__main__":
    import uvicorn
    uvicorn.run("main:app", host="0.0.0.0", port=8000, reload=True)
