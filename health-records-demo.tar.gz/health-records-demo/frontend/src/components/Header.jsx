import { Bell, User } from "lucide-react";

export default function Header() {
  return (
    <header className="header">
      <h1 className="header-title">Personal & Family Health Records</h1>
      <div className="header-actions">
        <button className="icon-btn" title="Notifications">
          <Bell size={20} />
        </button>
        <button className="icon-btn" title="Profile">
          <User size={20} />
        </button>
      </div>
    </header>
  );
}
