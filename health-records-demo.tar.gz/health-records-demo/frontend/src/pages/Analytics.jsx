import { Activity } from "lucide-react";

/**
 * Health Analytics & Trends
 *
 * TODO:
 * - Parameter trend charts (HbA1c, BP, cholesterol, etc.)
 * - Date range selector
 * - Parameter picker dropdown
 * - Abnormal value highlights
 * - AI-generated insights
 * - Report comparison view
 * - Export graphs
 */

export default function Analytics() {
  return (
    <div className="page">
      <h2>Health Analytics</h2>

      <div className="card">
        <h3>Parameter Trends</h3>
        <div className="chart-placeholder">
          <Activity size={48} />
          <p>Charts will appear here once lab results are uploaded and extracted.</p>
          <p className="text-muted">Track HbA1c, blood pressure, cholesterol, and more over time.</p>
        </div>
      </div>

      <div className="card">
        <h3>AI Insights</h3>
        <p className="placeholder">AI-generated health insights will appear here based on your records.</p>
      </div>
    </div>
  );
}
