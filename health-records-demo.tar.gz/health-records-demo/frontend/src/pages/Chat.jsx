import { useState, useRef, useEffect } from "react";
import { Send, Bot, User } from "lucide-react";
import { sendChatMessage, getChatHistory } from "../services/api";

/**
 * AI Health Assistant — conversational interface
 *
 * TODO:
 * - Connect to backend chat endpoint (Gemini RAG)
 * - Load chat history on mount
 * - Patient selector
 * - Show source references in AI responses
 * - Suggested questions
 * - Typing indicator
 * - Auto-scroll to bottom
 */

export default function Chat() {
  const [messages, setMessages] = useState([
    { role: "assistant", content: "Hello! I'm your AI health assistant. Ask me anything about your medical records, medications, or lab results." },
  ]);
  const [input, setInput] = useState("");
  const [loading, setLoading] = useState(false);
  const bottomRef = useRef();

  const handleSend = async () => {
    if (!input.trim() || loading) return;
    const userMsg = input.trim();
    setInput("");
    setMessages((prev) => [...prev, { role: "user", content: userMsg }]);
    setLoading(true);

    try {
      // TODO: Use selected patient ID
      const res = await sendChatMessage(1, userMsg);
      setMessages((prev) => [...prev, { role: "assistant", content: res.data.reply }]);
    } catch {
      setMessages((prev) => [
        ...prev,
        { role: "assistant", content: "Sorry, I couldn't process that. Please try again." },
      ]);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  return (
    <div className="page chat-page">
      <h2>AI Health Assistant</h2>

      <div className="chat-container">
        <div className="chat-messages">
          {messages.map((msg, i) => (
            <div key={i} className={`chat-msg ${msg.role}`}>
              {msg.role === "assistant" ? <Bot size={20} /> : <User size={20} />}
              <div className="chat-bubble">{msg.content}</div>
            </div>
          ))}
          {loading && (
            <div className="chat-msg assistant">
              <Bot size={20} />
              <div className="chat-bubble typing">Thinking...</div>
            </div>
          )}
          <div ref={bottomRef} />
        </div>

        <div className="chat-input-bar">
          <input
            type="text"
            className="input"
            placeholder="Ask about your health records..."
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={(e) => e.key === "Enter" && handleSend()}
          />
          <button className="btn btn-primary" onClick={handleSend} disabled={loading}>
            <Send size={18} />
          </button>
        </div>

        {/* Suggested questions */}
        <div className="suggested-questions">
          {[
            "What medications am I currently taking?",
            "How has my HbA1c changed over time?",
            "Show my recent lab results",
            "Summarize my medical history",
          ].map((q) => (
            <button key={q} className="btn btn-outline" onClick={() => setInput(q)}>
              {q}
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}
