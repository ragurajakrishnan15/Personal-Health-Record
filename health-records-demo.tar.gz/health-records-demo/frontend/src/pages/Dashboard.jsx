import { useEffect, useState } from "react";
import { FileText, Pill, AlertTriangle, Calendar } from "lucide-react";
import { getHealthSummary } from "../services/api";

/**
 * Dashboard — patient health overview
 *
 * TODO:
 * - Fetch real health summary from API
 * - Show stat cards (active meds, pending reviews, documents, upcoming appts)
 * - Recent lab results with abnormal flags
 * - Quick upload CTA
 * - Family member switcher
 */

export default function Dashboard() {
  const [summary, setSummary] = useState(null);

  useEffect(() => {
    // TODO: Get selected patient ID from context/state
    // getHealthSummary(patientId).then(r => setSummary(r.data));
  }, []);

  return (
    <div className="page">
      <h2>Health Overview</h2>

      <div className="stats-grid">
        <div className="stat-card">
          <FileText size={24} />
          <div>
            <span className="stat-value">—</span>
            <span className="stat-label">Documents</span>
          </div>
        </div>
        <div className="stat-card">
          <Pill size={24} />
          <div>
            <span className="stat-value">—</span>
            <span className="stat-label">Active Medications</span>
          </div>
        </div>
        <div className="stat-card">
          <AlertTriangle size={24} />
          <div>
            <span className="stat-value">—</span>
            <span className="stat-label">Pending Reviews</span>
          </div>
        </div>
        <div className="stat-card">
          <Calendar size={24} />
          <div>
            <span className="stat-value">—</span>
            <span className="stat-label">Upcoming Appointments</span>
          </div>
        </div>
      </div>

      <section className="card">
        <h3>Recent Lab Results</h3>
        <p className="placeholder">No lab results yet. Upload a report to get started.</p>
      </section>

      <section className="card">
        <h3>Medical Timeline</h3>
        <p className="placeholder">Timeline will appear here as records are added.</p>
      </section>
    </div>
  );
}
