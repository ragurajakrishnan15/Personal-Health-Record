import { useEffect, useState } from "react";
import { Pill } from "lucide-react";
import { getMedications } from "../services/api";

/**
 * Medication Management
 *
 * TODO:
 * - Active / Past medication tabs
 * - Medication cards with dosage, frequency, timing
 * - Status badges (active, paused, completed, discontinued)
 * - Medication timeline / history
 * - Adherence tracking
 * - Add manual medication entry
 */

export default function Medications() {
  const [meds, setMeds] = useState([]);
  const [filter, setFilter] = useState("active");

  useEffect(() => {
    // TODO: Use selected patient ID
    // getMedications(patientId, filter).then(r => setMeds(r.data));
  }, [filter]);

  return (
    <div className="page">
      <h2>Medications</h2>

      <div className="tab-bar">
        {["active", "completed", "discontinued", "all"].map((f) => (
          <button
            key={f}
            className={`tab ${filter === f ? "active" : ""}`}
            onClick={() => setFilter(f)}
          >
            {f.charAt(0).toUpperCase() + f.slice(1)}
          </button>
        ))}
      </div>

      <div className="med-list">
        {meds.length === 0 ? (
          <p className="placeholder">No medications found. Upload a prescription to auto-extract medications.</p>
        ) : (
          meds.map((med) => (
            <div key={med.id} className="card med-card">
              <Pill size={20} />
              <div>
                <strong>{med.name}</strong>
                {med.strength && <span> — {med.strength}</span>}
                <p>{med.dosage} · {med.frequency} · {med.timing}</p>
                <p className="text-muted">{med.instructions}</p>
              </div>
              <span className={`badge badge-${med.status}`}>{med.status}</span>
            </div>
          ))
        )}
      </div>
    </div>
  );
}
