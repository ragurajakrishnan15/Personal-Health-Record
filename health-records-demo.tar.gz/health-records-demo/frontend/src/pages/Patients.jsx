import { useEffect, useState } from "react";
import { UserPlus } from "lucide-react";
import { getPatients, createPatient } from "../services/api";

/**
 * Family / Patient Management
 *
 * TODO:
 * - List family members as cards
 * - Add new patient form (modal)
 * - Patient health snapshot on each card
 * - Click to navigate to patient profile
 * - Role badges (Admin, Patient, Caregiver, Viewer)
 */

export default function Patients() {
  const [patients, setPatients] = useState([]);
  const [showForm, setShowForm] = useState(false);

  useEffect(() => {
    getPatients().then((r) => setPatients(r.data)).catch(console.error);
  }, []);

  return (
    <div className="page">
      <div className="page-header">
        <h2>Family Members</h2>
        <button className="btn btn-primary" onClick={() => setShowForm(true)}>
          <UserPlus size={18} /> Add Member
        </button>
      </div>

      {/* TODO: Add patient form modal */}

      <div className="patient-grid">
        {patients.length === 0 ? (
          <p className="placeholder">No family members yet. Add one to get started.</p>
        ) : (
          patients.map((p) => (
            <div key={p.id} className="card patient-card">
              <h3>{p.name}</h3>
              <p>{p.age ? `${p.age} yrs` : ""} {p.gender || ""}</p>
              <p>{p.blood_group || "Blood group not set"}</p>
            </div>
          ))
        )}
      </div>
    </div>
  );
}
