import { useEffect, useState } from "react";
import { FileText, CheckCircle, Clock, XCircle } from "lucide-react";
import { getDocuments } from "../services/api";

/**
 * Medical Records browser
 *
 * TODO:
 * - List uploaded documents with status badges
 * - Filter by category, date, doctor, hospital
 * - Click to open document detail / validation view
 * - Show extracted data alongside original document
 * - Validation actions (verify, correct, reject)
 */

const statusIcon = {
  pending_review: <Clock size={16} className="text-warning" />,
  verified: <CheckCircle size={16} className="text-success" />,
  rejected: <XCircle size={16} className="text-danger" />,
};

export default function Records() {
  const [documents, setDocuments] = useState([]);

  useEffect(() => {
    // TODO: Use selected patient ID
    // getDocuments(patientId).then(r => setDocuments(r.data));
  }, []);

  return (
    <div className="page">
      <h2>Medical Records</h2>

      {/* TODO: Filter bar */}
      <div className="filter-bar">
        <select className="select"><option>All Categories</option></select>
        <select className="select"><option>All Doctors</option></select>
        <input type="date" className="input" />
      </div>

      <div className="records-list">
        {documents.length === 0 ? (
          <p className="placeholder">No records yet. Upload a medical document to get started.</p>
        ) : (
          documents.map((doc) => (
            <div key={doc.id} className="card record-card">
              <FileText size={20} />
              <div>
                <strong>{doc.filename}</strong>
                <span className="badge">{doc.category}</span>
                {statusIcon[doc.validation_status]}
              </div>
              <span className="date">{doc.document_date || doc.upload_date}</span>
            </div>
          ))
        )}
      </div>
    </div>
  );
}
