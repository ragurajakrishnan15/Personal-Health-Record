import { useState, useRef } from "react";
import { Upload as UploadIcon, FileUp, Loader } from "lucide-react";
import { uploadDocument } from "../services/api";

/**
 * Document Upload + AI Extraction + Validation
 *
 * TODO:
 * - Drag-and-drop zone
 * - Multi-file upload
 * - Camera capture (mobile)
 * - Show extraction progress
 * - Side-by-side: original doc preview | extracted fields
 * - Editable extracted fields with confidence indicators
 * - Validate / Correct / Reject actions
 * - Auto-create medications, lab results, timeline events from extraction
 */

export default function UploadPage() {
  const [file, setFile] = useState(null);
  const [uploading, setUploading] = useState(false);
  const [result, setResult] = useState(null);
  const fileRef = useRef();

  const handleUpload = async () => {
    if (!file) return;
    setUploading(true);
    try {
      // TODO: Use selected patient ID
      const patientId = 1;
      const res = await uploadDocument(patientId, file);
      setResult(res.data);
    } catch (err) {
      console.error(err);
    } finally {
      setUploading(false);
    }
  };

  return (
    <div className="page">
      <h2>Upload Medical Document</h2>

      <div
        className="upload-zone"
        onClick={() => fileRef.current?.click()}
      >
        <UploadIcon size={48} />
        <p>{file ? file.name : "Click or drag a file here"}</p>
        <span>PDF, JPG, PNG — Prescriptions, Lab Reports, Discharge Summaries</span>
        <input
          ref={fileRef}
          type="file"
          accept=".pdf,.jpg,.jpeg,.png"
          hidden
          onChange={(e) => setFile(e.target.files[0])}
        />
      </div>

      <button
        className="btn btn-primary"
        onClick={handleUpload}
        disabled={!file || uploading}
      >
        {uploading ? <><Loader size={18} className="spin" /> Processing...</> : <><FileUp size={18} /> Upload & Extract</>}
      </button>

      {/* Extraction results */}
      {result && (
        <div className="extraction-result">
          <div className="card">
            <h3>Extracted Information</h3>
            <p><strong>Category:</strong> {result.category}</p>
            <p><strong>Doctor:</strong> {result.doctor || "—"}</p>
            <p><strong>Hospital:</strong> {result.hospital || "—"}</p>
            <p><strong>Date:</strong> {result.document_date || "—"}</p>
            <p><strong>Status:</strong> {result.validation_status}</p>

            {/* TODO: Show extracted medications, lab results, diagnoses */}
            {/* TODO: Editable fields with confidence scores */}
            {/* TODO: Validate / Correct / Reject buttons */}

            <pre className="extracted-json">
              {JSON.stringify(result.extracted_data, null, 2)}
            </pre>
          </div>
        </div>
      )}
    </div>
  );
}
