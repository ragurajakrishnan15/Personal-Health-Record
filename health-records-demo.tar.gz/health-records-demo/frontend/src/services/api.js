/**
 * API service — all backend calls go through here.
 * Base URL switches between dev proxy and production.
 */
import axios from "axios";

const api = axios.create({
  baseURL: "/api",
});

// ── Patients ──────────────────────────────────────────
export const getPatients = () => api.get("/patients");
export const getPatient = (id) => api.get(`/patients/${id}`);
export const createPatient = (data) => api.post("/patients", data);

// ── Documents ─────────────────────────────────────────
export const uploadDocument = (patientId, file) => {
  const form = new FormData();
  form.append("file", file);
  return api.post(`/patients/${patientId}/documents`, form);
};
export const getDocuments = (patientId) =>
  api.get(`/patients/${patientId}/documents`);
export const validateDocument = (docId, data) =>
  api.put(`/documents/${docId}/validate`, data);

// ── Medications ───────────────────────────────────────
export const getMedications = (patientId, status) =>
  api.get(`/patients/${patientId}/medications`, { params: { status } });
export const updateMedicationStatus = (medId, status) =>
  api.put(`/medications/${medId}/status`, null, { params: { status } });

// ── Lab Results ───────────────────────────────────────
export const getLabResults = (patientId, testName) =>
  api.get(`/patients/${patientId}/lab-results`, { params: { test_name: testName } });

// ── Timeline ──────────────────────────────────────────
export const getTimeline = (patientId) =>
  api.get(`/patients/${patientId}/timeline`);

// ── Health Summary ────────────────────────────────────
export const getHealthSummary = (patientId) =>
  api.get(`/patients/${patientId}/health-summary`);

// ── Chat ──────────────────────────────────────────────
export const sendChatMessage = (patientId, message) =>
  api.post("/chat", { patient_id: patientId, message });
export const getChatHistory = (patientId) =>
  api.get(`/patients/${patientId}/chat-history`);

export default api;
